# Isolated reset executor — implemented-unverified

No hardware was connected or moved during implementation. Independent review and
operator-controlled physical validation remain required. This is not a statement
that the existing long segments or original settings are physically safe.

## Usage

From `杂项/reset_lab`:

```bash
env -u PYTHONPATH -u LD_LIBRARY_PATH -u LD_PRELOAD .venv-executor/bin/python \
  execute_reset.py points/points-20261018-121415.json
```

Default is offline preview, including every recorded segment and final E→A.
The unknown current→A segment is printed after explicit connection, without a
confirmation pause before motion. Empty files fail before native import/connection; one
point visits A once. Episode is default; `--mode startup` is unconditional.
`--force-interpolation` (episode only) forces the first pass, retaining the
position-only retry condition and maximum three passes. No duration override.

Only after review, the operator may append
`--execute --log evidence/<new-unique-name>.jsonl`. `--execute` is execution consent:
after preflight and initial logging, connection and route start automatically,
with a stdout warning and no typed confirmations or terminal requirement.
Without `--execute`, the script remains an offline preview. Before invoking, confirm exclusive ownership,
original numeric collision settings, entire swept arm workspace, empty load,
small initial test, Desk ready, and emergency stop reachable. Stop official
teleoperation/Ray/readers yourself; this script kills no services. DeviceClaim uses
the exact official lock path/key; a TCP preflight also refuses existing sessions.
Neither mechanism excludes unmanaged clients on another host or all race conditions.

## Exact behavior and deliberate boundaries

- Config snapshot `single_franka.yaml` is byte-identical to 52cdf9a. The base YAML
  supplies inherited request Kt=2000; effective episode Kt/Kr=1200/80, xyz clip=.02,
  rotation clip=.15. Startup Kt/Kr=1000/50, clips=.008/.04. Both keep max_step=.08,
  max_step_rad=.20, max_delta_tau=.3, gains_time_constant=.1, nullspace=5.
- Motion-only extraction preserves linspace and original SLERP, 15 float32
  commands, send then sleep .1s; episode `allclose(actual[:3], target[:3], .02)`
  uses rtol=.02 and default atol=1e-8, no orientation gate, maximum three attempts.
  Startup internal 1-second wait is repeated for each target. Intermediate route
  dwell is 2 seconds; last→A has no additional route dwell; final A ends.
- Actual pinned Franky CartesianImpedanceTracker is rebuilt, not substituted.
  Driver tracking, guard, gains and recovery methods are AST-compared to snapshots.
  Native nullspace, gain smoothing, rotational quaternion-vector error, clips and
  torque rate algorithm are unchanged. No joint reset/random reset, gripper,
  camera, reward or episode accounting is executed.
- The original constructor writes collision thresholds 20Nm/30N; original driver
  then writes torque [80,80,80,80,11,11,11] and force [100,100,100,25,25,25], recovery,
  dynamics=.2. These are not new tuning values. If approval for these inherited
  writes is absent, DO NOT execute; escalate rather than substitute other values.
  Desk is not configured. Original per-command recovery is retained after checking
  tracking failure; exceptions abort without home travel. Shutdown deliberately
  avoids recovery and does not swallow stop errors.
- Measured frame is O_T_EE in both collector and driver; no frame setters. Raw
  column-major transform, TCP, q/dq, time/mode/errors and requested/applied targets
  are logged. This is application-rate sampling, not 1kHz telemetry.
- Native torque loop has no logging callback. Python telemetry is bounded and
  buffered in memory, serialized after stop; crash/power loss can lose it. State
  reads and logging bookkeeping add latency: 1.5s is sleep budget, NOT deadline.
  Fresh tracker lacks teleop history; no Ray/RPC. No claim of temporal equivalence.
- Ctrl-C/SIGTERM attempt stop; SIGKILL cannot. Stop return/process exit is NOT
  physical-stop confirmation. Inspect robot/Desk and emergency stop as needed.

## Build provenance and isolation

Franky source commit `7bdb567df879a771c3095fb5815a8324c94f2ce6`, Ruckig submodule
`8a10e0129e0fc854215c0699da3ed42139bdc39b`, downloaded immutable source archives
under vendor, licenses included. Prior release audit associates this commit with
the installed wheel's successful build workflow; it is NOT cryptographic
source-to-wheel attestation. We do not claim rebuilt binary identity.

Independent copied system Python 3.10.12 (`.venv-executor`, no system-site-packages),
dependencies installed with uv copy mode using Tsinghua mirror. `venv --copies`
reported missing ensurepip; interpreter/config were created, then uv successfully
installed packages without pip. Official Python 3.11 environment was untouched.
See `evidence/executor-packages.txt` and `executor-environment.json`.

`bash build_executor.sh` rebuilds the isolated source against the existing isolated
native libfranka 0.19 build, not the official wheel. First loader trial exposed
ROS Ruckig precedence; corrected RUNPATH puts isolated Ruckig first. Final
`executor-loaded-libraries.json` records actual loaded library paths and hashes.
System libc/C++/Eigen/Poco/fmt and ROS Pinocchio4/coal/Boost dependencies are shared
read-only; they differ from original wheel dependencies. This matters for physical
validation. No global packages, official code or `.venv` were changed.

`source_snapshot/`, `executor_config/`, `evidence/executor-source-manifest.json`
retain hashes/provenance. Native runtime hashes are checked/logged on each execute;
code/config hashes are logged rather than claiming immutable experimental files.

## Offline evidence / rollback

`env -u PYTHONPATH -u LD_LIBRARY_PATH -u LD_PRELOAD .venv-executor/bin/python -m unittest -v test_executor test_collect_points`

Offline tests cover golden interpolation/driver AST, dtype/timing, thresholds, skip,
force, retries, route/dwell, single/empty points, injected abort at every send,
interrupt/stop failure, no-native default, isolation gate, collector regression,
prompt-free explicit execution and retained preflight/log failure gates.
Native build/import/loader audit succeeds without robot construction.

Reviewer capacity fix: regular telemetry is bounded at 100000 records and fails
explicitly on exhaustion. Sixteen separate emergency slots retain abort, stop,
initialization failure and CLI failure records. Emergency reporting cannot bypass
cleanup; a simultaneous stop/logging failure does not replace the original error.
Reserve exhaustion is explicitly reported to stderr, never silently truncated.
Flush failures report potentially missing/partial records and unpersisted emergency
outcomes to stderr; they propagate unless preserving an existing execution error.
Evidence: `evidence/executor-capacity-tests.log` (including injected exhaustion,
startup cleanup, CLI failure/stop persistence and disk-write failure tests).

Rollback: remove only executor additions/environment/build and vendor Franky/
Ruckig archives in this lab; preserve collector, probe, point files and its SDK.
No automatic migration to official teleoperation.
