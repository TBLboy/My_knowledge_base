"""Motion-only extraction of RLinf reset, with explicit route/abort lifecycle."""
import time
import numpy as np
from .pose import quat_slerp
from .lifecycle import report, stop

def interpolate(control, target, emit, sleep=time.sleep):
    state = control.read()
    positions = np.linspace(state['tcp'][:3], target[:3], 16)
    quaternions = quat_slerp(state['tcp'][3:], target[3:], 16)
    for xyz, quat in zip(positions[1:], quaternions[1:]):
        pose = np.concatenate([xyz, quat]).astype(np.float32)
        control.send(pose)
        emit('send', requested=pose.tolist(), applied=control.applied(), measured=control.read())
        sleep(0.1)
    return control.read()

def reset_target(control, target, mode, force, emit, sleep=time.sleep):
    emit('reset_begin', target=target.tolist(), mode=mode, force_interpolation=force)
    if mode == 'startup':
        state = interpolate(control, target, emit, sleep)
        sleep(1.0)
        state = control.read()
        attempts = 1
    else:
        state = control.read()
        attempts = 0
        while not np.allclose(state['tcp'][:3], target[:3], 0.02) or (force and attempts == 0):
            attempts += 1
            interpolate(control, target, emit, sleep)
            state = control.read()
            if attempts > 2:
                break
        control.clear()
        state = control.read()
    emit('reset_return', attempts=attempts, skipped=attempts == 0,
         position_close=bool(np.allclose(state['tcp'][:3], target[:3], 0.02)),
         measured=state, position_error=(np.asarray(state['tcp'][:3])-target[:3]).tolist(),
         orientation_error_rad=float(2*np.arccos(np.clip(abs(np.dot(state['tcp'][3:], target[3:])), 0, 1))))

def run_route(control, points, mode, force, emit, sleep=time.sleep):
    """Single point visits once; exception unwinds directly to stop, never home."""
    original_error = None
    try:
        for index, target in enumerate(points):
            reset_target(control, target, mode, force, emit, sleep)
            if index < len(points)-1:
                sleep(2.0)
        if len(points) > 1:
            reset_target(control, points[0], mode, force, emit, sleep)
    except BaseException as error:
        original_error = error
        report(emit, 'abort', error=repr(error), automatic_return=False)
        raise
    finally:
        stop(control, emit, original_error)
