"""RLinf CartesianCompliance defaults and mapping semantics (Apache-2.0)."""
from dataclasses import dataclass, fields, replace
from pathlib import Path
import yaml

@dataclass
class CartesianCompliance:
    translational_stiffness: float = 500.0
    rotational_stiffness: float = 40.0
    nullspace_stiffness: float = 5.0
    translational_clip: float = 0.05
    rotational_clip: float = 0.3
    max_step: float = 0.10
    max_step_rad: float = 0.30
    max_delta_tau: float = 0.3
    gains_time_constant: float = 0.1
    stiffness_cap: float = 1200.0
    rotational_stiffness_cap: float = 80.0
    clip_floor: float = 0.005
    rotational_clip_floor: float = 0.02

    @classmethod
    def from_config(cls, value, *, defaults=None):
        if value is None:
            return cls() if defaults is None else replace(defaults)
        if isinstance(value, cls):
            return value
        given = dict(value)
        unknown = set(given) - {f.name for f in fields(cls)}
        if unknown:
            raise KeyError(f'Unknown compliance settings {unknown}')
        return replace(cls() if defaults is None else defaults,
                       **{k: float(v) for k, v in given.items()})

def load_config():
    root = Path(__file__).resolve().parents[1] / 'executor_config'
    config = yaml.safe_load((root / 'single_franka.yaml').read_text())
    base = yaml.safe_load((root / 'base_env.yaml').read_text())
    hardware = config['cluster']['node_groups'][0]['hardware']['configs'][0]
    request = dict(base['override_cfg']['compliance_param'])
    request.update(config['env']['eval']['override_cfg']['compliance_param'])
    return hardware, request
