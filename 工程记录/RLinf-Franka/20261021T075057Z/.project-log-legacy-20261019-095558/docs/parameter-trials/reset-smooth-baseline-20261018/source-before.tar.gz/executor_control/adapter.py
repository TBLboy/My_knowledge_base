"""Hardware boundary. Construct only after explicit local operator gates."""
import time
import numpy as np
from .driver import FrankyArm
from .lifecycle import report, stop

class Control:
    def __init__(self, hardware, request, mode, emit):
        self.arm = FrankyArm(hardware['robot_ip'], compliance=hardware['compliance'],
                             realtime_config=hardware['realtime_config'])
        self.emit = emit
        self.closed = False
        try:
            self.arm._open()
            if mode == 'episode':
                self.arm.reconfigure_compliance_params(request)
            emit('connected', applied=self.parameters(), measured=self.read())
        except BaseException as error:
            report(emit, 'initialization_failure', error=repr(error), physical_stop_confirmed=False)
            stop(self, emit, error)
            raise

    def parameters(self):
        a = self.arm
        return dict(K_t=a._cart_k_t, K_r=a._cart_k_r, K_ns=a._cart_k_ns,
                    trans_clip=a._cart_trans_clip.tolist(), rot_clip=a._cart_rot_clip.tolist(),
                    compliance=vars(a._compliance))

    def read(self):
        self.arm._check_tracking_motion()
        s = self.arm._robot.state
        t = s.O_T_EE
        return dict(tcp=list(t.translation)+list(t.quaternion), q=list(s.q), dq=list(s.dq),
                    O_T_EE_column_major=np.asarray(t.matrix).flatten(order='F').tolist(),
                    robot_time=str(s.time), robot_mode=str(s.robot_mode),
                    current_errors=str(s.current_errors), last_motion_errors=str(s.last_motion_errors),
                    host_ns=time.time_ns(), monotonic_ns=time.monotonic_ns())

    def clear(self):
        self.arm.clear_errors()

    def send(self, pose):
        self.clear()
        self.emit('dispatch', requested=pose.tolist())
        self.arm.move_tcp_pose(pose)

    def applied(self):
        return np.concatenate([self.arm._prev_cart_target_xyz,
                               self.arm._prev_cart_target_quat]).tolist()

    def close(self):
        if self.closed:
            return
        self.closed = True
        a = self.arm
        try:
            # No recovery on shutdown; do not swallow stop failure.
            if a._cart_tracker is not None:
                a._cart_tracker.stop()
            elif a._robot is not None:
                if a._robot.is_in_control:
                    a._robot.stop()
                a._robot.join_motion()
        finally:
            a._cart_tracker = None
            a._robot = None
            a._claim.release()
