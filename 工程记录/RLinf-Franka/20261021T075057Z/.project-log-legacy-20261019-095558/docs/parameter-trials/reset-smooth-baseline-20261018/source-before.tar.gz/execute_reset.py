"""Offline by default. Only a local operator may explicitly execute this experiment."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import numpy as np
from collect_points import validate, label
from executor_control.reset import run_route
from executor_control.settings import load_config
from executor_control.lifecycle import report, stop

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_points(path):
    raw = Path(path).read_bytes()
    document = json.loads(raw)
    if document.get('schema') != 'reset-lab-points-v1' or not document.get('points'):
        raise ValueError('Expected nonempty reset-lab-points-v1 file')
    result = []
    for index, point in enumerate(document['points']):
        parsed = validate(point)
        if point.get('label') != label(index):
            raise ValueError('Point labels must match file order')
        if point.get('frame') != 'base_to_measured_EE':
            raise ValueError('Expected measured EE frame; never silently set tool frame')
        if not np.allclose(point['xyz'], parsed['xyz'], atol=1e-8, rtol=0):
            raise ValueError('Point xyz disagrees with raw O_T_EE')
        if abs(abs(np.dot(point['quaternion_xyzw'], parsed['quaternion_xyzw']))-1) > 1e-8:
            raise ValueError('Point quaternion disagrees with raw O_T_EE')
        result.append(np.array(parsed['xyz'] + parsed['quaternion_xyzw']))
    return result, hashlib.sha256(raw).hexdigest()

def segment(a, b):
    return dict(distance_m=float(np.linalg.norm(b[:3]-a[:3])),
                angle_deg=float(np.degrees(2*np.arccos(np.clip(abs(np.dot(a[3:], b[3:])), 0, 1)))))

def preview(points):
    segments = []
    route = points + ([points[0]] if len(points) > 1 else [])
    for i, (a, b) in enumerate(zip(route, route[1:])):
        segments.append(dict(start=label(i), end=label(i+1) if i+1 < len(points) else 'A', **segment(a, b)))
    return dict(first='current->A: UNKNOWN until connection; operator must inspect',
                segments=segments, duration_s=1.5, samples=15, sleep_after_send_s=0.1,
                warning='Large moves are NOT smoothed or slowed. Entire swept arm workspace must be clear.')

def isolation():
    if Path(sys.prefix).resolve() != ROOT / '.venv-executor':
        raise RuntimeError('Use the isolated .venv-executor interpreter')
    if any(os.environ.get(k) for k in ('PYTHONPATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD')):
        raise RuntimeError('Unset PYTHONPATH, LD_LIBRARY_PATH and LD_PRELOAD')
    import franky
    import franky._franky
    for module in (np, franky, franky._franky):
        if not Path(module.__file__).resolve().is_relative_to(ROOT):
            raise RuntimeError(f'Nonisolated import: {module.__file__}')
    libraries = {}
    for line in Path('/proc/self/maps').read_text().splitlines():
        path = line.split()[-1]
        if path.startswith('/') and '.so' in path and Path(path).exists():
            if '/RLinf/' in path or '/RLinf-Franks/' in path:
                raise RuntimeError(f'Official runtime library loaded: {path}')
            if any(x in Path(path).name for x in ('franky', 'franka', 'ruckig')) and not Path(path).resolve().is_relative_to(ROOT):
                raise RuntimeError(f'Nonisolated robot library: {path}')
            libraries[path] = digest(path)
    return libraries

def provenance():
    files = [Path(__file__), ROOT/'collect_points.py']
    for folder in ('executor_control', 'executor_config', 'source_snapshot'):
        files += [p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
    return {str(p.relative_to(ROOT)): digest(p) for p in files}

def check_existing_connection(address):
    # A local advisory claim cannot detect unmanaged SDK clients. Inspect TCP too;
    # this is a preflight, NOT a race-free guarantee against other machines.
    # libfranka common/research_interface/robot/service_types.h: kCommandPort=1337.
    # Desk HTTPS (443) is not an FCI control connection and must remain usable.
    result = subprocess.run(['ss', '-Htn', 'dst', address, 'dport', '=', '1337'],
                            check=True, text=True, capture_output=True, timeout=5)
    if result.stdout.strip():
        raise RuntimeError('Existing FCI TCP connection to robot port 1337: stop its owner yourself')

class Journal:
    """Buffer outside native RT thread; write only before/after route. Bounded memory."""
    EMERGENCY = frozenset(('abort', 'stop', 'failure', 'initialization_failure'))

    def __init__(self, stream, capacity=100000, emergency_capacity=16):
        self.stream, self.events = stream, []
        self.capacity, self.emergency_capacity = capacity, emergency_capacity
        self.regular_count = self.emergency_count = 0
    def emit(self, event, **fields):
        if event in self.EMERGENCY:
            if self.emergency_count >= self.emergency_capacity:
                print(f'EMERGENCY BUFFER EXHAUSTED: {event} {fields!r}; '
                      'record NOT saved; physical stop NOT confirmed', file=sys.stderr)
                return
            self.emergency_count += 1
        else:
            if self.regular_count >= self.capacity:
                raise RuntimeError('Telemetry buffer exhausted: abort')
            self.regular_count += 1
        self.events.append(dict(event=event, host_ns=time.time_ns(), monotonic_ns=time.monotonic_ns(), **fields))
    def flush(self):
        try:
            for event in self.events:
                self.stream.write(json.dumps(event, allow_nan=False)+'\n')
            self.stream.flush()
            os.fsync(self.stream.fileno())
        except BaseException as error:
            print(f'JOURNAL WRITE FAILED: {error!r}; records may be missing/partial; '
                  'physical stop NOT confirmed', file=sys.stderr)
            for event in self.events:
                if event['event'] in self.EMERGENCY:
                    print(f'UNPERSISTED EMERGENCY: {event!r}', file=sys.stderr)
            raise
        self.events.clear()
        self.regular_count = self.emergency_count = 0

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('points', type=Path)
    parser.add_argument('--mode', choices=('startup', 'episode'), default='episode')
    parser.add_argument('--force-interpolation', action='store_true')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--log', type=Path)
    args = parser.parse_args(argv)
    points, points_hash = load_points(args.points)
    hardware, request = load_config()
    plan = preview(points)
    print(json.dumps(plan, indent=2))
    if args.force_interpolation and args.mode != 'episode':
        parser.error('--force-interpolation is an episode-only deviation')
    if not args.execute:
        print('DRY RUN: no connection, no Franky import, no motion. mode='+args.mode)
        return 0
    if args.log is None:
        parser.error('Execution requires new --log path')
    libraries = isolation()
    check_existing_connection(hardware['robot_ip'])
    print('EXPERIMENTAL, physically unverified. No services will be killed. Stop official Ray/teleop/readers yourself.')
    print('Connection preserves original writes: recovery, dynamics=.2; constructor collision 20Nm/30N, then '
          'torque=[80,80,80,80,11,11,11], force=[100,100,100,25,25,25]. No Desk changes.')
    print('Do not continue unless those existing thresholds are separately approved. No collision threshold tuning here.')
    from executor_control.adapter import Control
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    with args.log.open('x') as stream:
        journal = Journal(stream)
        journal.emit('start', points_sha256=points_hash, code=provenance(), libraries=libraries,
                     request=request, hardware=hardware, mode=args.mode, force=args.force_interpolation,
                     python=sys.version, plan=plan, temporal_equivalence=False,
                     limitations='Fresh tracker; no Ray/RPC; telemetry state reads add latency; 1.5s is sleep budget not deadline; buffered logs can be lost on crash')
        journal.flush()
        control = None
        original_error = None
        try:
            print('WARNING: --execute starts connection and route automatically, with no prompts. '
                  'Exclusive ownership, approved settings, clear swept workspace and reachable emergency stop required.', flush=True)
            control = Control(hardware, request, args.mode, journal.emit)
            initial = control.read()
            print('Measured current->A:', segment(np.array(initial['tcp']), points[0]), flush=True)
            run_route(control, points, args.mode, args.force_interpolation, journal.emit)
        except BaseException as error:
            original_error = error
            report(journal.emit, 'failure', error=repr(error), physical_stop_confirmed=False)
            if control is not None and not control.closed:
                stop(control, journal.emit, error)
            raise
        finally:
            try:
                journal.flush()
            except BaseException:
                if original_error is None:
                    raise
    return 0

if __name__ == '__main__':
    sys.exit(main())
