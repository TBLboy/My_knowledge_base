import ast
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import execute_reset as cli
from executor_control.reset import run_route, reset_target, interpolate
from executor_control.driver import FrankyArm
from executor_control.settings import load_config
from executor_control.pose import quat_slerp

P = np.array([.5, .1, .2, 0., 0., 0., 1.])

class ConnectionPreflightTests(unittest.TestCase):
    def test_queries_only_robot_fci_port(self):
        with patch.object(cli.subprocess, 'run') as run:
            run.return_value.stdout = ''
            cli.check_existing_connection('172.16.0.2')
            self.assertEqual(run.call_args.args[0],
                             ['ss', '-Htn', 'dst', '172.16.0.2', 'dport', '=', '1337'])

    def test_fci_connection_still_blocks(self):
        with patch.object(cli.subprocess, 'run') as run:
            run.return_value.stdout = 'ESTAB 0 0 172.16.0.200:40000 172.16.0.2:1337\n'
            with self.assertRaisesRegex(RuntimeError, '1337'):
                cli.check_existing_connection('172.16.0.2')

    def test_inspection_failure_propagates(self):
        with patch.object(cli.subprocess, 'run', side_effect=OSError('ss failed')):
            with self.assertRaises(OSError):
                cli.check_existing_connection('172.16.0.2')

class CliConsentTests(unittest.TestCase):
    def setUp(self):
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        directory = self.stack.enter_context(tempfile.TemporaryDirectory())
        self.log = Path(directory)/'events.jsonl'
        self.argv = [str(cli.ROOT/'points/points-20261018-121415.json')]
        self.output = self.stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        self.stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
        self.stack.enter_context(patch('builtins.input', side_effect=AssertionError('must not prompt')))
        self.stack.enter_context(patch.object(cli.sys, 'stdin', None))
        self.stack.enter_context(patch.object(cli.signal, 'signal'))
        self.isolation = self.stack.enter_context(patch.object(cli, 'isolation', return_value={}))
        self.fci = self.stack.enter_context(patch.object(cli, 'check_existing_connection'))
        self.control = self.stack.enter_context(patch('executor_control.adapter.Control'))
        self.control.return_value.read.return_value = {'tcp': P.tolist()}
        self.route = self.stack.enter_context(patch.object(cli, 'run_route'))

    def execute(self):
        return cli.main(self.argv + ['--execute', '--log', str(self.log)])

    def test_execute_without_stdin_warns_before_connect_and_runs_route(self):
        def connect(*args):
            self.assertIn('automatically, with no prompts', self.output.getvalue())
            return self.control.return_value
        self.control.side_effect = connect
        self.assertEqual(self.execute(), 0)
        self.control.assert_called_once()
        self.route.assert_called_once()
        self.assertIn('Measured current->A:', self.output.getvalue())
        self.assertIn('segments', self.output.getvalue())
        self.assertTrue(self.log.exists())

    def test_default_never_connects(self):
        self.assertEqual(cli.main(self.argv), 0)
        for gate in (self.isolation, self.fci, self.control, self.route):
            gate.assert_not_called()

    def test_log_required(self):
        with self.assertRaises(SystemExit):
            cli.main(self.argv + ['--execute'])
        self.control.assert_not_called()

    def test_log_must_be_unique(self):
        self.log.write_text('preserve')
        with self.assertRaises(FileExistsError):
            self.execute()
        self.assertEqual(self.log.read_text(), 'preserve')
        self.control.assert_not_called()

    def test_isolation_failure_blocks_connection(self):
        self.isolation.side_effect = RuntimeError('isolation')
        with self.assertRaisesRegex(RuntimeError, 'isolation'):
            self.execute()
        self.fci.assert_not_called()
        self.control.assert_not_called()

    def test_fci_failure_blocks_connection(self):
        self.fci.side_effect = RuntimeError('FCI busy')
        with self.assertRaisesRegex(RuntimeError, 'FCI busy'):
            self.execute()
        self.control.assert_not_called()

    def test_control_ownership_failure_never_runs_route(self):
        self.control.side_effect = RuntimeError('ownership denied')
        with self.assertRaisesRegex(RuntimeError, 'ownership denied'):
            self.execute()
        self.route.assert_not_called()
        self.assertEqual(json.loads(self.log.read_text().splitlines()[-1])['event'], 'failure')

class Fake:
    def __init__(self, follow=True, fail=None):
        self.pose, self.sent = P.copy(), []
        self.follow, self.fail, self.stops = follow, fail, 0
    def read(self):
        return dict(tcp=self.pose.tolist(), q=[0]*7, dq=[0]*7)
    def send(self, pose):
        self.sent.append(pose.copy())
        if self.fail == len(self.sent):
            raise RuntimeError('injected send failure')
        if self.follow:
            self.pose = pose.astype(float)
    def applied(self):
        return self.sent[-1].tolist()
    def clear(self):
        pass
    def close(self):
        self.stops += 1

class Tests(unittest.TestCase):
    def setUp(self):
        self.events, self.sleeps = [], []
    def emit(self, kind, **fields):
        self.events.append((kind, fields))
    def reset(self, control, target, mode='episode', force=False):
        reset_target(control, target, mode, force, self.emit, self.sleeps.append)
    def test_orientation_only_skip_and_force(self):
        target = P.copy(); target[3:] = [1,0,0,0]
        fake = Fake(); self.reset(fake, target)
        self.assertEqual(len(fake.sent), 0)
        self.reset(fake, target, force=True)
        self.assertEqual(len(fake.sent), 15)
    def test_rtol_not_centimeters(self):
        for delta, moves in ((.009, False), (.011, True)):
            target = P.copy(); target[0] += delta
            fake = Fake(); self.reset(fake, target)
            self.assertEqual(bool(fake.sent), moves)
        fake = Fake(); fake.pose[1] = 0
        target = fake.pose.copy(); target[1] = .000001
        self.reset(fake, target)
        self.assertTrue(fake.sent)
    def test_three_attempts(self):
        fake = Fake(follow=False); target = P.copy(); target[0] += .1
        self.reset(fake, target)
        self.assertEqual(len(fake.sent), 45)
    def test_startup_unconditional_and_wait(self):
        fake = Fake(); self.reset(fake, P, 'startup')
        self.assertEqual(len(fake.sent), 15)
        self.assertEqual(self.sleeps, [.1]*15+[1.])
        self.assertTrue(all(p.dtype == np.float32 for p in fake.sent))
    def test_route_and_dwell(self):
        points = [P.copy() for _ in range(5)]
        for i,p in enumerate(points): p[0] += .1*i
        fake = Fake()
        run_route(fake, points, 'episode', False, self.emit, self.sleeps.append)
        visits = [e['target'] for k,e in self.events if k=='reset_begin']
        np.testing.assert_allclose(visits, points+[points[0]])
        self.assertEqual(self.sleeps.count(2.), 4)
        self.assertEqual(fake.stops, 1)
    def test_single(self):
        fake = Fake(); run_route(fake, [P], 'startup', False, self.emit, self.sleeps.append)
        self.assertEqual(len(fake.sent), 15)
        self.assertNotIn(2., self.sleeps)
    def test_failure_every_step_never_return(self):
        points = [P.copy(), P.copy()]; points[1][0] += .2
        for step in range(1, 31):
            fake = Fake(fail=step); self.events=[]
            with self.assertRaises(RuntimeError):
                run_route(fake, points, 'startup', False, self.emit, lambda _:None)
            visits = [e for k,e in self.events if k=='reset_begin']
            self.assertLessEqual(len(visits), 2)
            self.assertEqual(fake.stops, 1)
    def test_interrupt_no_return(self):
        fake=Fake()
        with self.assertRaises(KeyboardInterrupt):
            run_route(fake, [P,P], 'startup', False, self.emit,
                      lambda _: (_ for _ in ()).throw(KeyboardInterrupt()))
        self.assertEqual(fake.stops, 1)
    def test_stop_failure_reported(self):
        fake=Fake(); fake.close=lambda: (_ for _ in ()).throw(RuntimeError('stop'))
        with self.assertRaises(RuntimeError):
            run_route(fake, [P], 'episode', False, self.emit, lambda _:None)
        self.assertEqual(self.events[-1][1]['result'], 'failed')
    def test_empty_rejected(self):
        with tempfile.TemporaryDirectory(dir=cli.ROOT/'build') as d:
            path=Path(d)/'empty.json'; path.write_text(json.dumps({'schema':'reset-lab-points-v1','points':[]}))
            with self.assertRaises(ValueError): cli.load_points(path)
    def test_default_no_native_import_or_connection(self):
        with patch.object(cli, 'isolation', side_effect=AssertionError('native gate')), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main([str(cli.ROOT/'points/points-20261018-121415.json')]), 0)
    def test_config_applied_caps(self):
        hardware, request=load_config()
        arm=FrankyArm(hardware['robot_ip'], hardware['compliance'])
        self.assertEqual((arm._cart_k_t,arm._cart_k_r),(1000,50))
        np.testing.assert_equal(arm._cart_trans_clip,[.008]*3)
        arm.reconfigure_compliance_params(request)
        self.assertEqual((arm._cart_k_t,arm._cart_k_r),(1200,80))
        np.testing.assert_equal(arm._cart_trans_clip,[.02]*3)
        np.testing.assert_equal(arm._cart_rot_clip,[.15]*3)
        self.assertEqual(arm._compliance.max_step,.08)
        self.assertEqual(arm._compliance.max_step_rad,.2)
    def test_golden_driver_methods_unchanged(self):
        def methods(path):
            tree=ast.parse(path.read_text())
            return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
        old=methods(cli.ROOT/'source_snapshot/franky_driver.py')
        new=methods(cli.ROOT/'executor_control/driver.py')
        for name in ('move_tcp_pose','_ensure_cart_tracking_motion','_check_tracking_motion',
                     'reconfigure_compliance_params','default_compliance','_open','clear_errors'):
            self.assertEqual(old[name],new[name],name)
    def test_golden_interpolation(self):
        tree=ast.parse((cli.ROOT/'source_snapshot/env_base.py').read_text())
        node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_interpolate_move')
        namespace=dict(np=np, quat_slerp=quat_slerp, time=type('Clock',(),{'sleep':lambda _:None}), FrankaRobotState=object)
        exec(compile(ast.Module(body=[node],type_ignores=[]),'snapshot','exec'),namespace)
        class Original:
            config=type('Config',(),{'step_frequency':10.})
            def __init__(self): self.sent=[]
            def _read_robot(self): return type('State',(),{'tcp_pose':P})
            def _move_action(self,p): self.sent.append(p)
        for quat in ([0,0,0,1],[0,0,0,-1],[.5,.5,.5,.5]):
            target=P.copy();target[0]+=.2;target[3:]=quat
            original=Original();namespace['_interpolate_move'](original,target)
            fake=Fake();interpolate(fake,target,self.emit,lambda _:None)
            np.testing.assert_array_equal(original.sent,fake.sent)
    def test_isolation_gate(self):
        with patch.dict('os.environ', {'PYTHONPATH':'/forbidden'}):
            with self.assertRaises(RuntimeError):cli.isolation()

    def test_capacity_reserves_shutdown_records(self):
        journal=cli.Journal(io.StringIO(), capacity=1)
        fake=Fake()
        with self.assertRaisesRegex(RuntimeError, 'Telemetry buffer exhausted'):
            run_route(fake, [P,P], 'startup', False, journal.emit, lambda _:None)
        journal.emit('failure', error='Telemetry buffer exhausted')
        self.assertEqual(fake.stops, 1)
        self.assertEqual([e['event'] for e in journal.events],
                         ['reset_begin','abort','stop','failure'])
        self.assertEqual(journal.events[-2]['result'], 'stop_call_returned')

    def test_capacity_and_stop_failure_preserve_original(self):
        journal=cli.Journal(io.StringIO(), capacity=0)
        fake=Fake()
        def fail_stop():
            fake.stops+=1
            raise ValueError('stop also failed')
        fake.close=fail_stop
        with self.assertRaisesRegex(RuntimeError, 'Telemetry buffer exhausted'):
            run_route(fake, [P], 'startup', False, journal.emit, lambda _:None)
        self.assertEqual(fake.stops, 1)
        self.assertEqual(journal.events[-1]['result'], 'failed')

    def test_emergency_report_failure_never_prevents_stop(self):
        fake=Fake()
        error=RuntimeError('all logging broken')
        def emit(*args, **kwargs): raise error
        with contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(RuntimeError) as caught:
                run_route(fake,[P],'startup',False,emit,lambda _:None)
        self.assertIs(caught.exception,error)
        self.assertEqual(fake.stops,1)
        self.assertIn('EMERGENCY LOG FAILED',stderr.getvalue())

    def test_write_failure_reports_unpersisted_stop(self):
        class Broken(io.StringIO):
            def write(self, value): raise OSError('disk full')
        journal=cli.Journal(Broken(),capacity=0)
        journal.emit('stop',result='failed')
        with contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaisesRegex(OSError,'disk full'):journal.flush()
        self.assertIn('UNPERSISTED EMERGENCY',stderr.getvalue())
        self.assertEqual(len(journal.events),1)

    def test_emergency_reserve_overflow_is_explicit(self):
        journal=cli.Journal(io.StringIO(),capacity=0,emergency_capacity=1)
        journal.emit('abort',error='first')
        with contextlib.redirect_stderr(io.StringIO()) as stderr:
            journal.emit('stop',result='failed')
        self.assertEqual(len(journal.events),1)
        self.assertIn('record NOT saved',stderr.getvalue())
        self.assertIn('stop',stderr.getvalue())

    def test_initialization_capacity_failure_stops(self):
        from executor_control.adapter import Control
        hardware, request=load_config()
        journal=cli.Journal(io.StringIO(),capacity=0)
        with patch.object(FrankyArm,'_open'), patch.object(Control,'read',return_value={}), \
             patch.object(Control,'close') as close:
            with self.assertRaisesRegex(RuntimeError,'Telemetry buffer exhausted'):
                Control(hardware,request,'startup',journal.emit)
        close.assert_called_once()
        self.assertEqual([e['event'] for e in journal.events],['initialization_failure','stop'])

    def test_cli_capacity_failure_records_cleanup_and_original(self):
        from executor_control.adapter import Control
        real_journal=cli.Journal
        fake=Fake();fake.closed=False
        def close(): fake.stops+=1;fake.closed=True
        fake.close=close
        with tempfile.TemporaryDirectory(dir=cli.ROOT/'build') as directory:
            path=Path(directory)/'events.jsonl'
            with patch.object(cli,'isolation',return_value={}), \
                 patch.object(cli,'check_existing_connection'), \
                 patch('builtins.input',side_effect=AssertionError('must not prompt')), \
                 patch('executor_control.adapter.Control',return_value=fake), \
                 patch.object(cli.signal,'signal'), \
                 patch.object(cli,'Journal',side_effect=lambda stream:real_journal(stream,capacity=1)), \
                 contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError,'Telemetry buffer exhausted'):
                    cli.main([str(cli.ROOT/'points/points-20261018-121415.json'),
                              '--execute','--log',str(path)])
            events=[json.loads(line) for line in path.read_text().splitlines()]
        self.assertEqual(fake.stops,1)
        self.assertEqual([e['event'] for e in events][-3:],['abort','stop','failure'])

if __name__=='__main__': unittest.main()
