"""Best-effort emergency reporting must never prevent stopping the controller."""
import sys

def report(emit, event, **fields):
    try:
        emit(event, **fields)
    except BaseException as error:
        print(f'EMERGENCY LOG FAILED: {event} {fields!r}; logging error={error!r}; '
              'physical stop NOT confirmed', file=sys.stderr)

def stop(control, emit, original_error=None):
    try:
        control.close()
    except BaseException as error:
        report(emit, 'stop', result='failed', error=repr(error), physical_stop_confirmed=False)
        if original_error is None:
            raise
    else:
        report(emit, 'stop', result='stop_call_returned', physical_stop_confirmed=False)
